
package lec8;


public class processor {
    public static void main(String[] args) {
        overloading a = new overloading();
        System.out.println(a.sum(1, 2));
        System.out.println(a.sum(1, 2,3));
    }
}
