
package lec8;


public class overloading {
    int a ; 
    int b ;
    int c ;
    int sum(int a , int b)
    {
        return (a+b);
    }
        int sum(int a , int b,int c)
    {
        return (a+b+c);
    }
}
