
package lec8;


public class process {
    public static void main(String[] args) {
        Student a = new Student(10, "minh");
        Student b = new Student(10, "minh" ,19);
        a.display();
        b.display();
    }
}
